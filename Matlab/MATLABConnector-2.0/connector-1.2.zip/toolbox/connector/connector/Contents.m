% MATLAB Connector
% Version 1.2 (R2009b) 01-Jan-2011 
%
% MATLAB Connector 
%   connector      - Enables the MATLAB Connector

% Helper Files
%   setupconnector - Set up the MATLAB Connector on the desktop
%   connector-help - Help text for MATLAB Connector

%   Copyright 2010-2011 The MathWorks, Inc. 